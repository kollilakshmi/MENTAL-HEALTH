<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Health Quiz Results</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .result-container { max-width: 600px; margin: 50px auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; background: #f4f4f9; }
        h1, h2, h3 { text-align: center; }
        .score { text-align: center; font-size: 1.5em; margin-bottom: 20px; }
        .answer-summary { margin-top: 30px; }
        .answer { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="result-container">
        <h1>Mental Health Quiz Results</h1>

        <?php
        // Define options and their weights for each question
        $options_weights = [
            "q1" => [
                1 => 0, // Option 1 weight
                2 => 40, // Option 2 weight
                3 => 60, // Option 3 weight
                4 => 80, // Option 4 weight
                5 => 100,  // Option 5 weight
            ],
            "q2" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ],
            "q3" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ], 
            "q4" => [
                1 => 0, // Option 1 weight
                2 => 40, // Option 2 weight
                3 => 60, // Option 3 weight
                4 => 80, // Option 4 weight
                5 => 100,  // Option 5 weight
            ],
            "q5" => [
                1 => 0, // Option 1 weight
                2 => 40, // Option 2 weight
                3 => 60, // Option 3 weight
                4 => 80, // Option 4 weight
                5 => 100,  // Option 5 weight
            ],
            "q6" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ], 
            "q7" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ], 
            "q8" => [
                1 => 0, // Option 1 weight
                2 => 40, // Option 2 weight
                3 => 60, // Option 3 weight
                4 => 80, // Option 4 weight
                5 => 100,  // Option 5 weight
            ],
            "q9" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ], 
            "q10" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ], 
            "q11" => [
                1 => 100,
                2 => 80,
                3 => 60,
                4 => 40,
                5 => 0,
            ], 


            
           
        ];

        // Initialize variables
        $total_questions = count($options_weights);
        $total_responses = count($_POST); // Assuming all questions are answered in the form submission

        // Initialize option percentages
        $option_percentages = [];
        foreach ($options_weights as $question => $weights) {
            $option_percentages[$question] = [];

            // Initialize percentages
            foreach ($weights as $option => $weight) {
                $option_percentages[$question][$option] = 0;
            }
        }

        // Count user selections for each option
        foreach ($_POST as $key => $value) {
            if (array_key_exists($key, $options_weights)) {
                $user_answer = intval($value);

                // Increment count for user's selection
                if (array_key_exists($user_answer, $option_percentages[$key])) {
                    $option_percentages[$key][$user_answer]++;
                }
            }
        }

        // Calculate percentages
        foreach ($option_percentages as $question => &$options) {
            foreach ($options as $option => &$count) {
                $percentage = ($count / $total_responses) * 100;
                $options[$option] = round($percentage, 2); // Round percentage to 2 decimal places
            }
        }

        // Output results
        echo "<div class='answer-summary'>";
        foreach ($option_percentages as $question => $options) {
            echo "<div class='answer'>";
            echo "<h3>Question $question:</h3>";
            foreach ($options as $option => $percentage) {
                echo "<p>Option $option: $percentage%</p>";
            }
            echo "</div>";
        }
        echo "</div>";
        ?>

    </div>
</body>
</html>
